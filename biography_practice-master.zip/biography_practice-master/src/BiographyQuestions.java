public class BiographyQuestions {
   public static final String askFirstName = "What is your favorite author’s first name?";
   public static final String askLastName = "What is your favorite author’s last name?";
   public static final String askCountry = "Where is your favorite author from?";
   public static final String askIfAlive = "Is your favorite author alive? Y/N";
   public static final String askAge = "How old is your favorite author?";
   public static final String askToEnterBook = "Would you like enter book information? (Y/N)";
   public static final String askBookName = "What is the book name?";
   public static final String askGenre = "What is genre of the book?";
   public static final String askPages = "How many pages does book have?";

}
